package your.org.myapp.internal.tasks;

import org.cytoscape.work.AbstractTaskFactory;
import org.cytoscape.work.TaskIterator;

/**
 * This is a very simple TaskFactory that really doesn't do
 * anything.
 */

public class MyAppTaskFactory extends AbstractTaskFactory {
	public MyAppTaskFactory() {
		super();
	}

	/**
	 * This is mandatory.  Note that in this case, we're not
	 * returning any tasks.  This will generate an error, but
	 * we'll fix that up in the next step.
	 */
	public TaskIterator createTaskIterator () {
		return new TaskIterator();
	}

	/**
	 * Return true, so we're always active.
	 */
	public boolean isReady() { return true; }
}
