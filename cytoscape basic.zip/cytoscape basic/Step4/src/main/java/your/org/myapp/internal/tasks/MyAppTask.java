package your.org.myapp.internal.tasks;

import java.awt.Color;
import java.awt.Paint;
import java.util.Arrays;
import java.util.List;

import org.cytoscape.model.CyColumn;
import org.cytoscape.model.CyEdge;
import org.cytoscape.model.CyNetwork;
import org.cytoscape.model.CyNetworkFactory;
import org.cytoscape.model.CyNetworkManager;
import org.cytoscape.model.CyNode;
import org.cytoscape.model.CyTable;
import org.cytoscape.view.model.CyNetworkView;
import org.cytoscape.view.model.CyNetworkViewFactory;
import org.cytoscape.view.model.CyNetworkViewManager;
import org.cytoscape.view.model.View;
import org.cytoscape.view.presentation.property.BasicVisualLexicon;
import org.cytoscape.view.presentation.property.NodeShapeVisualProperty;
import org.cytoscape.view.presentation.property.values.NodeShape;
import org.cytoscape.view.vizmap.VisualMappingFunctionFactory;
import org.cytoscape.view.vizmap.VisualMappingManager;
import org.cytoscape.view.vizmap.VisualStyle;
import org.cytoscape.view.vizmap.VisualStyleFactory;
import org.cytoscape.view.vizmap.mappings.BoundaryRangeValues;
import org.cytoscape.view.vizmap.mappings.ContinuousMapping;
import org.cytoscape.work.AbstractTask;
import org.cytoscape.work.ProvidesTitle;
import org.cytoscape.work.TaskFactory;
import org.cytoscape.work.TaskIterator;
import org.cytoscape.work.TaskMonitor;

public class MyAppTask extends AbstractTask {
	final CyNetworkManager netManager;
	final CyNetworkFactory netFactory;
	final CyNetworkViewManager viewManager;
	final CyNetworkViewFactory viewFactory;
	final	VisualMappingManager vmm;
	final	VisualMappingFunctionFactory cFactory;
	final	VisualStyleFactory vFactory;

	public MyAppTask(CyNetworkManager networkManager, CyNetworkFactory networkFactory,
	                 CyNetworkViewManager viewManager, CyNetworkViewFactory viewFactory,
	                 VisualMappingManager vmm, VisualStyleFactory vFactory,
	                 VisualMappingFunctionFactory cFactory) {
		super();
		netManager = networkManager;
		netFactory = networkFactory;
		this.viewManager = viewManager;
		this.viewFactory = viewFactory;
		this.vmm = vmm;
		this.cFactory = cFactory;
		this.vFactory = vFactory;
	}

	public void run(TaskMonitor monitor) {
		CyNetwork myNetwork = netFactory.createNetwork();
		CyNode node1 = myNetwork.addNode();
		CyNode node2 = myNetwork.addNode();
		CyEdge edge1 = myNetwork.addEdge(node1, node2, false);

		myNetwork.getRow(node1).set(CyNetwork.NAME, "Node1");
		myNetwork.getRow(node2).set(CyNetwork.NAME, "Node2");
		myNetwork.getRow(edge1).set(CyNetwork.NAME, "Edge2");
		myNetwork.getRow(myNetwork).set(CyNetwork.NAME, "NetworkName");

		// Create our new columns
		CyTable nodeTable = myNetwork.getDefaultNodeTable();
		// CyTable nodeTable = myNetwork.getTable(CyNode.class, CyNetwork.DEFAULT_ATTRS);
		if (nodeTable.getColumn("Hello") == null) {
			nodeTable.createListColumn("Hello", String.class, false);
		}
		if (nodeTable.getColumn("World") == null) {
			nodeTable.createColumn("World", Double.class, false);
		}

		// Now, add the data
		myNetwork.getRow(node1).set("Hello",Arrays.asList("One", "Two", "Three"));
		// nodeTable.getRow(node1.getSUID()).set("Hello",Arrays.asList("One", "Two", "Three"));
		myNetwork.getRow(node2).set("Hello",Arrays.asList("Four", "Five", "Six"));
		// nodeTable.getRow(node2.getSUID()).set("Hello",Arrays.asList("One", "Two", "Three"));

		myNetwork.getRow(node1).set("World",1.0);
		myNetwork.getRow(node2).set("World",4.0);
		netManager.addNetwork(myNetwork);
		monitor.setStatusMessage("Added network");

		// Create our view
		CyNetworkView view = viewFactory.createNetworkView(myNetwork);
		viewManager.addNetworkView(view);

		// First, just set the appropriate locked values
		View<CyNode> nodeView1 = view.getNodeView(node1);
		View<CyNode> nodeView2 = view.getNodeView(node2);
		nodeView1.setLockedValue(BasicVisualLexicon.NODE_SHAPE, NodeShapeVisualProperty.DIAMOND);
		nodeView2.setLockedValue(BasicVisualLexicon.NODE_SHAPE, NodeShapeVisualProperty.ELLIPSE);

		List<String> node1Hello = myNetwork.getRow(node1).getList("Hello", String.class);
		List<String> node2Hello = myNetwork.getRow(node2).getList("Hello", String.class);
		nodeView1.setLockedValue(BasicVisualLexicon.NODE_LABEL, node1Hello.get(0));
		nodeView2.setLockedValue(BasicVisualLexicon.NODE_LABEL, node2Hello.get(0));

		// Now create the visual style we're going to use
		VisualStyle style = vmm.getVisualStyle(view);
		VisualStyle myStyle = vFactory.createVisualStyle(style); // Make a copy of it

		// And set up our ContinuousMapping
		ContinuousMapping mapping = (ContinuousMapping) 
     cFactory.createVisualMappingFunction("World", 
                                             Double.class,
                                             BasicVisualLexicon.NODE_FILL_COLOR);  
		// Define the points 
		Double val1 = 0d;
		BoundaryRangeValues<Paint> brv1 = 
			new BoundaryRangeValues<Paint>(Color.BLACK, Color.BLUE, Color.BLUE);
		Double val2 = 5d; 
		BoundaryRangeValues<Paint> brv2 = 
			new BoundaryRangeValues<Paint>(Color.YELLOW, Color.YELLOW, Color.BLACK); 

		// Set the points 
		mapping.addPoint(val1, brv1); 
		mapping.addPoint(val2, brv2); 

		// add the mapping to visual style
		myStyle.addVisualMappingFunction(mapping); 
		vmm.addVisualStyle(myStyle);
		vmm.setVisualStyle(myStyle, view);

	}

	@ProvidesTitle
	public String getTitle() { return "MyApp Task"; }

}
