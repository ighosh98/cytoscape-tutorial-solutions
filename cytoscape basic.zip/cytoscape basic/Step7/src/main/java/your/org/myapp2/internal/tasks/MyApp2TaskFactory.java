package edu.ucsf.rbvi.myapp2.internal.tasks;

import org.cytoscape.service.util.CyServiceRegistrar;
import org.cytoscape.work.AbstractTaskFactory;
import org.cytoscape.work.TaskFactory;
import org.cytoscape.work.TaskIterator;

public class MyApp2TaskFactory extends AbstractTaskFactory {
	final CyServiceRegistrar registrar;
	public MyApp2TaskFactory(final CyServiceRegistrar registrar) {
		super();
		this.registrar = registrar;
	}

	public TaskIterator createTaskIterator () {
		return new TaskIterator(new MyApp2Task(registrar));
	}

	public boolean isReady() { 
		// If we wanted to be "correct", we should check the availability of MyApp here...
		return true; 
	}
}
